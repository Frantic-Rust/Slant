#!/bin/sh
export NODE_BINARY=node
../node_modules/react-native/packager/react-native-xcode.sh
